package Clasesdao;

import Clases.Detalle;
import SQL.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DetalleDAO {

    public boolean insertar(Detalle d) {
        String sql = "INSERT INTO dbo.detalle (iddetalle, idfactura, idproducto, cantidad, precioUnitario) " +
                     "VALUES (?,?,?,?,?)";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, d.getIddetalle());
            ps.setInt(2, d.getIdfactura());
            ps.setInt(3, d.getIdproducto());
            ps.setInt(4, d.getCantidad());
            ps.setBigDecimal(5, d.getPrecioUnitario());
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("DetalleDAO.insertar: " + e.getMessage());
            return false;
        }
    }

    public List<Detalle> listarPorFactura(int idfactura) {
        List<Detalle> lista = new ArrayList<>();
        String sql = "SELECT iddetalle, idfactura, idproducto, cantidad, precioUnitario " +
                     "FROM dbo.detalle WHERE idfactura=? ORDER BY iddetalle";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, idfactura);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Detalle(
                        rs.getInt("iddetalle"),
                        rs.getInt("idfactura"),
                        rs.getInt("idproducto"),
                        rs.getInt("cantidad"),
                        rs.getBigDecimal("precioUnitario")
                    ));
                }
            }
        } catch (SQLException e) {
            System.out.println("DetalleDAO.listarPorFactura: " + e.getMessage());
        }
        return lista;
    }

    public boolean eliminar(int iddetalle) {
        String sql = "DELETE FROM dbo.detalle WHERE iddetalle=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, iddetalle);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("DetalleDAO.eliminar: " + e.getMessage());
            return false;
        }
    }
}
