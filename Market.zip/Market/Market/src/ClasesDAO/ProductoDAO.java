package Clasesdao;

import Clases.Producto;
import SQL.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    public boolean insertar(Producto p) {
        String sql = "INSERT INTO dbo.producto (idproducto, nombre, precioProducto, stock) VALUES (?,?,?,?)";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, p.getIdproducto());
            ps.setString(2, p.getNombre());
            ps.setBigDecimal(3, p.getPrecioProducto());
            ps.setInt(4, p.getStock());
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("ProductoDAO.insertar: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Producto p) {
        String sql = "UPDATE dbo.producto SET nombre=?, precioProducto=?, stock=? WHERE idproducto=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setString(1, p.getNombre());
            ps.setBigDecimal(2, p.getPrecioProducto());
            ps.setInt(3, p.getStock());
            ps.setInt(4, p.getIdproducto());
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("ProductoDAO.actualizar: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idproducto) {
        String sql = "DELETE FROM dbo.producto WHERE idproducto=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, idproducto);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("ProductoDAO.eliminar: " + e.getMessage());
            return false;
        }
    }

    public Producto buscarPorId(int idproducto) {
        String sql = "SELECT idproducto, nombre, precioProducto, stock FROM dbo.producto WHERE idproducto=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, idproducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Producto(
                        rs.getInt("idproducto"),
                        rs.getString("nombre"),
                        rs.getBigDecimal("precioProducto"),
                        rs.getInt("stock")
                    );
                }
            }
        } catch (SQLException e) {
            System.out.println("ProductoDAO.buscarPorId: " + e.getMessage());
        }
        return null;
    }

    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT idproducto, nombre, precioProducto, stock FROM dbo.producto ORDER BY idproducto";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = (ps != null ? ps.executeQuery() : null)) {

            if (cn == null) throw new SQLException("Conexión nula");

            while (rs.next()) {
                lista.add(new Producto(
                    rs.getInt("idproducto"),
                    rs.getString("nombre"),
                    rs.getBigDecimal("precioProducto"),
                    rs.getInt("stock")
                ));
            }
        } catch (SQLException e) {
            System.out.println("ProductoDAO.listarTodos: " + e.getMessage());
        }
        return lista;
    }
    
}
