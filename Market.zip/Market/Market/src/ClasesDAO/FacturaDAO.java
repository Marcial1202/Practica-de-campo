package Clasesdao;

import Clases.Factura;
import SQL.Conexion;

import java.sql.*;
import java.time.LocalDate;

public class FacturaDAO {

    public boolean insertar(Factura f) {
        String sql = "INSERT INTO dbo.factura (idfactura, fechaFactura) VALUES (?,?)";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, f.getIdfactura());
            ps.setDate(2, Date.valueOf(f.getFechaFactura()));
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("FacturaDAO.insertar: " + e.getMessage());
            return false;
        }
    }

    public Factura buscarPorId(int idfactura) {
        String sql = "SELECT idfactura, fechaFactura FROM dbo.factura WHERE idfactura=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, idfactura);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Factura(
                        rs.getInt("idfactura"),
                        rs.getDate("fechaFactura").toLocalDate()
                    );
                }
            }
        } catch (SQLException e) {
            System.out.println("FacturaDAO.buscarPorId: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminar(int idfactura) {
        String sql = "DELETE FROM dbo.factura WHERE idfactura=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setInt(1, idfactura);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("FacturaDAO.eliminar: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarFecha(int idfactura, LocalDate nuevaFecha) {
        String sql = "UPDATE dbo.factura SET fechaFactura=? WHERE idfactura=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            if (cn == null) throw new SQLException("Conexión nula");

            ps.setDate(1, Date.valueOf(nuevaFecha));
            ps.setInt(2, idfactura);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("FacturaDAO.actualizarFecha: " + e.getMessage());
            return false;
        }
    }
}
